package com.example.medquest

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
