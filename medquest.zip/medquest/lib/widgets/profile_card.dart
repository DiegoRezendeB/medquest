import 'package:flutter/material.dart';
import '../core/theme.dart';

class ProfileCard extends StatelessWidget {
  final String label;
  final IconData icon;
  const ProfileCard({required this.label, required this.icon, super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 6),
      child: Material(
        color: Colors.grey.shade100,
        borderRadius: BorderRadius.circular(12),
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: () {},
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 18),
            child: Row(
              children: [
                Icon(icon, color: kColorPrimary),
                const SizedBox(width: 16),
                Text(label,
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w500)),
                const Spacer(),
                const Icon(Icons.arrow_forward_ios_rounded,
                    size: 16, color: Colors.black54),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
