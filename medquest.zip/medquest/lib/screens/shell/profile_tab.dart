// lib/screens/shell/profile_tab.dart
import 'package:flutter/material.dart';
import '../../core/theme.dart';
import '../../widgets/gradient_header.dart';
import '../../widgets/profile_card.dart';

class ProfileTab extends StatelessWidget {
  const ProfileTab({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        children: [
          const GradientHeader(title: 'Perfil'),
          Container(
            height: 200,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [kColorPrimaryLight, kColorPrimary],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
            alignment: Alignment.center,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: const [
                CircleAvatar(
                  radius: 46,
                  backgroundColor: Colors.white,
                  child: Icon(Icons.person, size: 54, color: Colors.black54),
                ),
                SizedBox(height: 12),
                Text(
                  'Diêgo Rezende Badaró',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 32),
          const ProfileCard(label: 'Editar perfil', icon: Icons.edit_outlined),
          const ProfileCard(label: 'Excluir conta', icon: Icons.delete_outline),
          const ProfileCard(label: 'Sobre a versão', icon: Icons.info_outline),
        ],
      ),
    );
  }
}
