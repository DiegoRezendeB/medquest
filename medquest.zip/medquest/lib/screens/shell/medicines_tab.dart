import 'package:flutter/material.dart';
import '../../widgets/gradient_header.dart';

class MedicinesTab extends StatelessWidget {
  const MedicinesTab({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Column(
        children: const [
          GradientHeader(title: 'Medicamentos'),
          Expanded(
              child: Center(
                  child: Text('Lista de medicamentos',
                      style: TextStyle(fontSize: 20))))
        ],
      ),
    );
  }
}
