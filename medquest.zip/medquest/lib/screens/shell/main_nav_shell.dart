import 'package:flutter/material.dart';
import '../../core/theme.dart';
import 'home_tab.dart';
import 'appointments_tab.dart';
import 'medicines_tab.dart';
import 'profile_tab.dart';

class MainNavShell extends StatefulWidget {
  const MainNavShell({super.key});

  @override
  State<MainNavShell> createState() => _MainNavShellState();
}

class _MainNavShellState extends State<MainNavShell> {
  int _index = 0;
  final _pages = const [
    HomeTab(),
    AppointmentsTab(),
    MedicinesTab(),
    ProfileTab(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _pages[_index],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _index,
        type: BottomNavigationBarType.fixed,
        selectedItemColor: kColorPrimary,
        unselectedItemColor: Colors.black45,
        onTap: (i) => setState(() => _index = i),
        items: const [
          BottomNavigationBarItem(
              icon: Icon(Icons.home_outlined), label: 'Início'),
          BottomNavigationBarItem(
              icon: Icon(Icons.event_note_outlined), label: 'Consultas'),
          BottomNavigationBarItem(
              icon: Icon(Icons.medication_outlined), label: 'Medicamentos'),
          BottomNavigationBarItem(
              icon: Icon(Icons.person_outline), label: 'Perfil'),
        ],
      ),
    );
  }
}
