// lib/screens/shell/appointments_tab.dart
import 'package:flutter/material.dart';
import '../../widgets/gradient_header.dart';
import '../../widgets/appointment_card.dart';
import '../../core/theme.dart';

class AppointmentsTab extends StatelessWidget {
  const AppointmentsTab({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Column(children: [
        const GradientHeader(title: 'Consultas'),
        Padding(
          padding: const EdgeInsets.fromLTRB(24, 24, 24, 12),
          child: SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              icon: const Icon(Icons.add, color: Colors.white),
              label: const Text('Marcar Nova Consulta'),
              onPressed: () {},
            ),
          ),
        ),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            children: const [
              AppointmentCard(
                title: 'Consulta de rotina',
                date: '30 Mai',
                time: '14:00',
                icon: Icons.favorite_border,
                tint: Color(0xff4caf50),
              ),
              AppointmentCard(
                title: 'Consulta com o Dr. Silva',
                date: '15 Jun',
                time: '09:00',
                icon: Icons.medical_services_outlined,
                tint: Color(0xffffc400),
              ),
              AppointmentCard(
                title: 'Exame de sangue',
                date: '23 Jun',
                time: '10:00',
                icon: Icons.bloodtype_outlined,
                tint: kColorPrimary, // correção aqui
              ),
            ],
          ),
        ),
      ]),
    );
  }
}
