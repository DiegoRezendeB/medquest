// lib/screens/shell/home_tab.dart
import 'package:flutter/material.dart';
import '../../core/theme.dart';

class HomeTab extends StatelessWidget {
  const HomeTab({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(24, 24, 24, 32),
        children: [
          /*────────── título do app ──────────*/
          Text('MedQuest',
              style: TextStyle(
                  color: kColorPrimary,
                  fontSize: 32,
                  fontWeight: FontWeight.w800)),
          const SizedBox(height: 24),

          /*────────── saudação ──────────*/
          const Text('Bem-vindo de volta, Diêgo',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.w600)),
          const SizedBox(height: 32),

          /*────────── próximos compromissos ──────────*/
          _SectionHeader(
            title: 'Próximos compromissos',
            onTap: () {},
          ),
          const SizedBox(height: 12),
          const _NextItem(label: 'Consulta com o Dr. Silva'),
          const _NextItem(label: 'Exame de sangue'),
          const _NextItem(label: 'Clareamento nos dentes'),
          const _NextItem(label: 'Tomar o Espironolactona'),
          const SizedBox(height: 32),

          /*────────── médicos especializados ──────────*/
          _SectionHeader(
            title: 'Médicos especializados',
            onTap: () {},
          ),
          const SizedBox(height: 12),

          GridView(
            physics: const NeverScrollableScrollPhysics(),
            shrinkWrap: true,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              mainAxisSpacing: 16,
              crossAxisSpacing: 16,
              childAspectRatio: .95,
            ),
            children: const [
              _SpecialtyCard(icon: Icons.local_hospital, label: 'Médico Geral'),
              _SpecialtyCard(icon: Icons.face_retouching_natural, label: 'Dermatologia'),
              _SpecialtyCard(icon: Icons.psychology_outlined, label: 'Neurologia'),
              _SpecialtyCard(icon: Icons.child_care, label: 'Pediatria'),
              _SpecialtyCard(icon: Icons.air, label: 'Pneumologia'),
              _SpecialtyCard(icon: Icons.accessibility_new, label: 'Ortopedia'),
              _SpecialtyCard(icon: Icons.self_improvement, label: 'Psiquiatria'),
              _SpecialtyCard(icon: Icons.remove_red_eye_outlined, label: 'Oftalmologia'),
              _SpecialtyCard(icon: Icons.favorite_border, label: 'Cardiologia'),
            ],
          ),
        ],
      ),
    );
  }
}

/*──────────────── helpers ───────────────*/

class _SectionHeader extends StatelessWidget {
  final String title;
  final VoidCallback onTap;
  const _SectionHeader({required this.title, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Text(title,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
        const Spacer(),
        GestureDetector(
          onTap: onTap,
          child: Text('Ver todos',
              style: TextStyle(
                  color: kColorPrimary,
                  fontWeight: FontWeight.w600,
                  fontSize: 14)),
        ),
      ],
    );
  }
}

class _NextItem extends StatelessWidget {
  final String label;
  const _NextItem({required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 4),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        color: Colors.grey.shade100,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Icon(Icons.check_circle_outline, color: kColorPrimary),
          const SizedBox(width: 12),
          Expanded(child: Text(label)),
        ],
      ),
    );
  }
}

class _SpecialtyCard extends StatelessWidget {
  final IconData icon;
  final String label;
  const _SpecialtyCard({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.grey.shade100,
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () {}, // ação futura
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: kColorPrimary, size: 28),
            const SizedBox(height: 8),
            Text(label,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 13)),
          ],
        ),
      ),
    );
  }
}
