String? emailValidator(String? v) {
  if (v == null || v.trim().isEmpty) return 'Informe o e-mail';
  final r = RegExp(r'^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$');
  return r.hasMatch(v.trim()) ? null : 'E-mail inválido';
}
